// BankPO VocabMaster Main Application Logic
// Built for SBI PO, IBPS PO, & RBI Grade B Aspirants

// Web Audio synthesizer for crisp game sound effects (no external audio files required!)
const SoundFX = {
  ctx: null,
  init: function() {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (AudioCtx) this.ctx = new AudioCtx();
    }
  },
  playCorrect: function() {
    try {
      this.init();
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.type = "sine";
      const now = this.ctx.currentTime;
      osc.frequency.setValueAtTime(523.25, now); // C5
      osc.frequency.exponentialRampToValueAtTime(659.25, now + 0.1); // E5
      osc.frequency.exponentialRampToValueAtTime(783.99, now + 0.2); // G5
      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
      osc.start(now);
      osc.stop(now + 0.35);
    } catch (e) {}
  },
  playWrong: function() {
    try {
      this.init();
      if (!this.ctx) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.type = "sawtooth";
      const now = this.ctx.currentTime;
      osc.frequency.setValueAtTime(220, now); // A3
      osc.frequency.linearRampToValueAtTime(140, now + 0.25);
      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
      osc.start(now);
      osc.stop(now + 0.25);
    } catch (e) {}
  }
};

// Canvas Confetti generator
function fireConfetti() {
  const canvas = document.getElementById("confetti-canvas");
  if (!canvas) return;
  const ctx = canvas.getContext("2d");
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;

  const particles = [];
  const colors = ["#22c55e", "#3b82f6", "#f59e0b", "#ec4899", "#8b5cf6", "#10b981"];

  for (let i = 0; i < 75; i++) {
    particles.push({
      x: canvas.width / 2 + (Math.random() - 0.5) * 200,
      y: canvas.height / 2 + (Math.random() - 0.5) * 100,
      vx: (Math.random() - 0.5) * 12,
      vy: (Math.random() - 0.8) * 15,
      size: Math.random() * 8 + 4,
      color: colors[Math.floor(Math.random() * colors.length)],
      alpha: 1,
      rotation: Math.random() * 360,
      rotSpeed: (Math.random() - 0.5) * 10
    });
  }

  let animationId;
  function update() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    let alive = false;
    particles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;
      p.vy += 0.35; // gravity
      p.alpha -= 0.012;
      p.rotation += p.rotSpeed;

      if (p.alpha > 0) {
        alive = true;
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate((p.rotation * Math.PI) / 180);
        ctx.fillStyle = p.color;
        ctx.globalAlpha = Math.max(0, p.alpha);
        ctx.fillRect(-p.size / 2, -p.size / 2, p.size, p.size);
        ctx.restore();
      }
    });

    if (alive) {
      animationId = requestAnimationFrame(update);
    } else {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      cancelAnimationFrame(animationId);
    }
  }
  update();
}

// Pronunciation Helper using Web Speech API
function speakWord(text) {
  if (!('speechSynthesis' in window)) {
    alert("Speech synthesis is not supported on this browser.");
    return;
  }
  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = "en-US";
  utterance.rate = 0.88;
  window.speechSynthesis.speak(utterance);
}

// App State
const App = {
  currentTab: "flashcards", // 'flashcards', 'quiz', 'polarity', 'cloze', 'dict', 'mistakes'
  flashcardIndex: 0,
  flashcardDeck: [...VOCAB_DATA],
  isCardFlipped: false,

  // MCQ Quiz State
  quizQuestions: [],
  quizIndex: 0,
  quizScore: 0,
  quizAnswered: false,
  timerInterval: null,
  timeLeft: 20,

  // Tone Polarity Quiz State
  polarityQuestions: [],
  polarityIndex: 0,
  polarityScore: 0,
  polarityAnswered: false,

  // Cloze State
  clozeQuestions: [],
  clozeIndex: 0,
  clozeScore: 0,
  clozeAnswered: false,

  init: function() {
    this.bindEvents();
    this.updateStatsDisplay();
    this.initFlashcards();
    this.renderWordList();
  },

  bindEvents: function() {
    // Navigation tabs
    document.querySelectorAll(".nav-btn").forEach(btn => {
      btn.addEventListener("click", (e) => {
        const tab = btn.dataset.tab;
        this.switchTab(tab);
      });
    });

    // Flashcard Flip
    const flashcard = document.getElementById("flashcard");
    if (flashcard) {
      flashcard.addEventListener("click", (e) => {
        // Avoid flip if clicking sound or bookmark button
        if (e.target.closest(".action-btn")) return;
        this.flipCard();
      });
    }

    // Flashcard Controls
    document.getElementById("btn-prev-card")?.addEventListener("click", () => this.prevCard());
    document.getElementById("btn-next-card")?.addEventListener("click", () => this.nextCard());
    document.getElementById("btn-flip-card")?.addEventListener("click", () => this.flipCard());
    document.getElementById("btn-shuffle-card")?.addEventListener("click", () => this.shuffleCards());

    // Filter tier for flashcards
    document.getElementById("flashcard-tier-filter")?.addEventListener("change", (e) => {
      this.filterFlashcards(e.target.value);
    });

    // Theme Toggle
    document.getElementById("btn-toggle-theme")?.addEventListener("click", () => this.toggleTheme());

    // Search dictionary
    document.getElementById("dict-search")?.addEventListener("input", (e) => {
      this.filterDictionary();
    });
    document.getElementById("dict-tone-filter")?.addEventListener("change", () => {
      this.filterDictionary();
    });
    document.getElementById("dict-tier-filter")?.addEventListener("change", () => {
      this.filterDictionary();
    });
  },

  switchTab: function(tabName) {
    this.currentTab = tabName;
    document.querySelectorAll(".nav-btn").forEach(b => {
      b.classList.toggle("active", b.dataset.tab === tabName);
    });
    document.querySelectorAll(".tab-view").forEach(v => {
      v.classList.remove("active");
    });
    const targetView = document.getElementById(`view-${tabName}`);
    if (targetView) targetView.classList.add("active");

    // Clear any running timer
    clearInterval(this.timerInterval);

    // Tab-specific initializations
    if (tabName === "quiz") {
      this.startExamQuiz();
    } else if (tabName === "polarity") {
      this.startPolarityQuiz();
    } else if (tabName === "cloze") {
      this.startClozeQuiz();
    } else if (tabName === "mistakes") {
      this.renderMistakesView();
    } else if (tabName === "dict") {
      this.renderWordList();
    }
  },

  // ==========================================
  // FLASHCARD SYSTEM
  // ==========================================
  initFlashcards: function() {
    this.flashcardIndex = 0;
    this.isCardFlipped = false;
    this.renderCurrentCard();
  },

  filterFlashcards: function(tierFilter) {
    if (tierFilter === "all") {
      this.flashcardDeck = [...VOCAB_DATA];
    } else if (tierFilter === "bookmarks") {
      const bmarks = StorageManager.getBookmarks();
      this.flashcardDeck = VOCAB_DATA.filter(w => bmarks.includes(w.id));
      if (this.flashcardDeck.length === 0) {
        alert("No bookmarked words yet! Click the star on any card to save it.");
        this.flashcardDeck = [...VOCAB_DATA];
      }
    } else {
      this.flashcardDeck = VOCAB_DATA.filter(w => w.tier.includes(tierFilter));
    }
    this.flashcardIndex = 0;
    this.isCardFlipped = false;
    this.renderCurrentCard();
  },

  renderCurrentCard: function() {
    const card = this.flashcardDeck[this.flashcardIndex];
    if (!card) return;

    StorageManager.recordWordExplored(card.id);
    this.updateStatsDisplay();

    // Elements
    const cardEl = document.getElementById("flashcard");
    if (cardEl) {
      cardEl.classList.toggle("flipped", this.isCardFlipped);
    }

    // Counter
    const counterEl = document.getElementById("card-counter");
    if (counterEl) {
      counterEl.textContent = `${this.flashcardIndex + 1} / ${this.flashcardDeck.length}`;
    }

    // Front Side
    document.getElementById("card-word").textContent = card.word;
    document.getElementById("card-phonetic").textContent = card.phonetic;
    document.getElementById("card-pos").textContent = card.pos.toUpperCase();
    document.getElementById("card-tier-badge").textContent = card.tier;

    // Tone Badge Front
    const toneBadge = document.getElementById("card-tone-badge");
    toneBadge.className = `tone-badge tone-${card.tone}`;
    toneBadge.innerHTML = this.getToneIcon(card.tone) + " " + card.tone.toUpperCase() + " TONE";

    // Star icon state
    const isBookmarked = StorageManager.isBookmarked(card.id);
    const starBtn = document.getElementById("card-star-btn");
    if (starBtn) {
      starBtn.classList.toggle("bookmarked", isBookmarked);
      starBtn.innerHTML = isBookmarked ? "★ Bookmarked" : "☆ Bookmark";
      starBtn.onclick = (e) => {
        e.stopPropagation();
        const active = StorageManager.toggleBookmark(card.id);
        starBtn.classList.toggle("bookmarked", active);
        starBtn.innerHTML = active ? "★ Bookmarked" : "☆ Bookmark";
      };
    }

    // Pronunciation button
    const speakBtn = document.getElementById("card-speak-btn");
    if (speakBtn) {
      speakBtn.onclick = (e) => {
        e.stopPropagation();
        speakWord(card.word);
      };
    }

    // Back Side
    document.getElementById("back-word-title").textContent = card.word;
    document.getElementById("card-def").textContent = card.definition;
    document.getElementById("card-mnemonic").textContent = card.mnemonic;
    document.getElementById("card-context-sentence").textContent = `"${card.bankingContext}"`;
    document.getElementById("card-tone-explain").textContent = card.toneReason;

    // Synonyms & Antonyms tags
    const synContainer = document.getElementById("card-synonyms");
    synContainer.innerHTML = card.synonyms.map(s => `<span class="word-tag syn-tag">${s}</span>`).join("");

    const antContainer = document.getElementById("card-antonyms");
    antContainer.innerHTML = card.antonyms.map(a => `<span class="word-tag ant-tag">${a}</span>`).join("");
  },

  flipCard: function() {
    this.isCardFlipped = !this.isCardFlipped;
    const cardEl = document.getElementById("flashcard");
    if (cardEl) cardEl.classList.toggle("flipped", this.isCardFlipped);
  },

  nextCard: function() {
    this.isCardFlipped = false;
    this.flashcardIndex = (this.flashcardIndex + 1) % this.flashcardDeck.length;
    this.renderCurrentCard();
  },

  prevCard: function() {
    this.isCardFlipped = false;
    this.flashcardIndex = (this.flashcardIndex - 1 + this.flashcardDeck.length) % this.flashcardDeck.length;
    this.renderCurrentCard();
  },

  shuffleCards: function() {
    this.flashcardDeck.sort(() => 0.5 - Math.random());
    this.flashcardIndex = 0;
    this.isCardFlipped = false;
    this.renderCurrentCard();
  },

  getToneIcon: function(tone) {
    if (tone === "positive") return "▲ (+)";
    if (tone === "negative") return "▼ (-)";
    return "● (•)";
  },

  // ==========================================
  // EXAM MCQ QUIZ SYSTEM
  // ==========================================
  startExamQuiz: function() {
    clearInterval(this.timerInterval);
    this.quizIndex = 0;
    this.quizScore = 0;
    this.quizAnswered = false;

    // Generate balanced bank PO questions
    this.quizQuestions = this.generateQuizQuestions(10);
    this.renderQuizQuestion();
  },

  generateQuizQuestions: function(count = 10) {
    const questions = [];
    const shuffled = [...VOCAB_DATA].sort(() => 0.5 - Math.random()).slice(0, count);

    shuffled.forEach(wordObj => {
      // 50% chance Synonym, 50% chance Antonym
      const isSynonymType = Math.random() > 0.5;
      const questionType = isSynonymType ? "SYNONYM" : "ANTONYM";

      let correctAnswer = isSynonymType ? wordObj.synonyms[0] : wordObj.antonyms[0];

      // Generate 3 plausible distractors from other words
      const otherWords = VOCAB_DATA.filter(w => w.id !== wordObj.id);
      const distractors = [];
      while (distractors.length < 3 && otherWords.length > 0) {
        const randWord = otherWords[Math.floor(Math.random() * otherWords.length)];
        const pool = isSynonymType ? randWord.antonyms : randWord.synonyms;
        const candidate = pool[0];
        if (!distractors.includes(candidate) && candidate !== correctAnswer) {
          distractors.push(candidate);
        }
      }

      const options = [correctAnswer, ...distractors].sort(() => 0.5 - Math.random());

      questions.push({
        wordObj: wordObj,
        type: questionType,
        prompt: `Select the most appropriate ${questionType} for:`,
        targetWord: wordObj.word,
        options: options,
        correctAnswer: correctAnswer,
        tone: wordObj.tone,
        explanation: `${wordObj.word} (${wordObj.pos}) means: "${wordObj.definition}". Its most direct ${questionType.toLowerCase()} is "${correctAnswer}". Tone: ${wordObj.tone.toUpperCase()} (${wordObj.toneReason})`
      });
    });

    return questions;
  },

  renderQuizQuestion: function() {
    const q = this.quizQuestions[this.quizIndex];
    if (!q) {
      this.showQuizSummary();
      return;
    }

    this.quizAnswered = false;
    document.getElementById("quiz-feedback-box").classList.add("hidden");
    document.getElementById("quiz-next-btn").classList.add("hidden");

    // Question meta
    document.getElementById("quiz-progress").textContent = `Question ${this.quizIndex + 1} of ${this.quizQuestions.length}`;
    document.getElementById("quiz-score-badge").textContent = `Score: ${this.quizScore}`;

    // Prompt
    document.getElementById("quiz-type-tag").textContent = `${q.type} CHALLENGE`;
    document.getElementById("quiz-type-tag").className = `quiz-type-pill pill-${q.type.toLowerCase()}`;
    document.getElementById("quiz-word-target").textContent = q.targetWord;
    document.getElementById("quiz-word-tier").textContent = q.wordObj.tier;

    // Options
    const optionsContainer = document.getElementById("quiz-options");
    optionsContainer.innerHTML = "";

    q.options.forEach((opt, idx) => {
      const btn = document.createElement("button");
      btn.className = "quiz-option-btn";
      btn.innerHTML = `<span class="opt-letter">${String.fromCharCode(65 + idx)}</span> <span class="opt-text">${opt}</span>`;
      btn.onclick = () => this.handleQuizAnswer(opt, btn);
      optionsContainer.appendChild(btn);
    });

    // Start Timer (20 sec)
    this.startQuizTimer(20);
  },

  startQuizTimer: function(seconds) {
    clearInterval(this.timerInterval);
    this.timeLeft = seconds;
    const timerEl = document.getElementById("quiz-timer-text");
    const barEl = document.getElementById("quiz-timer-bar");

    timerEl.textContent = `${this.timeLeft}s`;
    barEl.style.width = "100%";

    this.timerInterval = setInterval(() => {
      this.timeLeft--;
      timerEl.textContent = `${this.timeLeft}s`;
      const pct = (this.timeLeft / seconds) * 100;
      barEl.style.width = `${pct}%`;

      if (this.timeLeft <= 5) {
        barEl.style.backgroundColor = "#ef4444";
      } else {
        barEl.style.backgroundColor = "#3b82f6";
      }

      if (this.timeLeft <= 0) {
        clearInterval(this.timerInterval);
        if (!this.quizAnswered) {
          this.handleQuizTimeout();
        }
      }
    }, 1000);
  },

  handleQuizAnswer: function(selectedOption, clickedBtn) {
    if (this.quizAnswered) return;
    this.quizAnswered = true;
    clearInterval(this.timerInterval);

    const q = this.quizQuestions[this.quizIndex];
    const isCorrect = selectedOption === q.correctAnswer;

    // Highlight options
    document.querySelectorAll(".quiz-option-btn").forEach(btn => {
      btn.disabled = true;
      const optText = btn.querySelector(".opt-text").textContent.trim();
      if (optText === q.correctAnswer) {
        btn.classList.add("correct-option");
      } else if (btn === clickedBtn && !isCorrect) {
        btn.classList.add("wrong-option");
      }
    });

    if (isCorrect) {
      this.quizScore += 10;
      SoundFX.playCorrect();
    } else {
      SoundFX.playWrong();
      StorageManager.recordMistake(q.wordObj.id, "MCQ " + q.type, selectedOption, q.correctAnswer);
    }

    StorageManager.recordQuizResult(isCorrect, q.wordObj.id);
    this.updateStatsDisplay();

    // Show feedback explanation
    const feedbackBox = document.getElementById("quiz-feedback-box");
    feedbackBox.className = `feedback-box ${isCorrect ? "feedback-success" : "feedback-danger"}`;
    feedbackBox.innerHTML = `
      <div class="feedback-title">${isCorrect ? "✓ Well Done! Exact Bank PO Match" : "✗ Incorrect Choice"}</div>
      <div class="feedback-desc">${q.explanation}</div>
      <div class="feedback-editorial"><strong>Editorial Context:</strong> "${q.wordObj.bankingContext}"</div>
    `;
    feedbackBox.classList.remove("hidden");

    // Show Next button
    const nextBtn = document.getElementById("quiz-next-btn");
    nextBtn.classList.remove("hidden");
    nextBtn.onclick = () => {
      this.quizIndex++;
      this.renderQuizQuestion();
    };
  },

  handleQuizTimeout: function() {
    this.quizAnswered = true;
    const q = this.quizQuestions[this.quizIndex];
    SoundFX.playWrong();
    StorageManager.recordQuizResult(false, q.wordObj.id);
    StorageManager.recordMistake(q.wordObj.id, "MCQ Timeout", "Timed Out", q.correctAnswer);
    this.updateStatsDisplay();

    document.querySelectorAll(".quiz-option-btn").forEach(btn => {
      btn.disabled = true;
      const optText = btn.querySelector(".opt-text").textContent.trim();
      if (optText === q.correctAnswer) btn.classList.add("correct-option");
    });

    const feedbackBox = document.getElementById("quiz-feedback-box");
    feedbackBox.className = "feedback-box feedback-danger";
    feedbackBox.innerHTML = `
      <div class="feedback-title">⏱ Time's Up!</div>
      <div class="feedback-desc">${q.explanation}</div>
    `;
    feedbackBox.classList.remove("hidden");

    const nextBtn = document.getElementById("quiz-next-btn");
    nextBtn.classList.remove("hidden");
    nextBtn.onclick = () => {
      this.quizIndex++;
      this.renderQuizQuestion();
    };
  },

  showQuizSummary: function() {
    const view = document.getElementById("view-quiz");
    const total = this.quizQuestions.length;
    const pct = Math.round((this.quizScore / (total * 10)) * 100);

    if (pct >= 80) fireConfetti();

    view.innerHTML = `
      <div class="summary-card">
        <div class="summary-badge">${pct >= 80 ? "🏆 Bank PO Ready!" : pct >= 50 ? "📈 Good Effort" : "📚 Needs Revision"}</div>
        <h2>Quiz Complete!</h2>
        <div class="summary-stats-grid">
          <div class="summary-stat-box">
            <span class="stat-big">${this.quizScore} / ${total * 10}</span>
            <span class="stat-lbl">Final Score</span>
          </div>
          <div class="summary-stat-box">
            <span class="stat-big">${pct}%</span>
            <span class="stat-lbl">Accuracy</span>
          </div>
        </div>
        <p class="summary-hint">Words answered incorrectly have been moved to your <strong>Review Vault</strong> for retesting.</p>
        <div class="summary-actions">
          <button class="btn btn-primary" onclick="App.startExamQuiz()">🔄 Retry New Quiz</button>
          <button class="btn btn-secondary" onclick="App.switchTab('flashcards')">📖 Review Flashcards</button>
          <button class="btn btn-warning" onclick="App.switchTab('mistakes')">⚠️ Open Vault</button>
        </div>
      </div>
    `;
  },

  // ==========================================
  // CREATIVE TONE & POLARITY CHALLENGE
  // ==========================================
  startPolarityQuiz: function() {
    this.polarityIndex = 0;
    this.polarityScore = 0;
    this.polarityAnswered = false;
    this.polarityQuestions = [...VOCAB_DATA].sort(() => 0.5 - Math.random()).slice(0, 10);
    this.renderPolarityQuestion();
  },

  renderPolarityQuestion: function() {
    const word = this.polarityQuestions[this.polarityIndex];
    if (!word) {
      this.showPolaritySummary();
      return;
    }

    this.polarityAnswered = false;
    document.getElementById("polarity-feedback").classList.add("hidden");
    document.getElementById("polarity-next-btn").classList.add("hidden");

    document.getElementById("polarity-progress").textContent = `Word ${this.polarityIndex + 1} of ${this.polarityQuestions.length}`;
    document.getElementById("polarity-score").textContent = `Score: ${this.polarityScore}`;

    document.getElementById("polarity-target-word").textContent = word.word;
    document.getElementById("polarity-sentence").textContent = `"${word.bankingContext}"`;

    // Re-enable polarity buttons
    document.querySelectorAll(".polarity-btn").forEach(b => {
      b.disabled = false;
      b.classList.remove("polarity-correct", "polarity-wrong");
    });
  },

  handlePolarityChoice: function(chosenTone) {
    if (this.polarityAnswered) return;
    this.polarityAnswered = true;

    const word = this.polarityQuestions[this.polarityIndex];
    const isCorrect = chosenTone === word.tone;

    document.querySelectorAll(".polarity-btn").forEach(b => {
      b.disabled = true;
      if (b.dataset.tone === word.tone) {
        b.classList.add("polarity-correct");
      } else if (b.dataset.tone === chosenTone && !isCorrect) {
        b.classList.add("polarity-wrong");
      }
    });

    if (isCorrect) {
      this.polarityScore += 10;
      SoundFX.playCorrect();
    } else {
      SoundFX.playWrong();
      StorageManager.recordMistake(word.id, "Tone Polarity", chosenTone, word.tone);
    }

    StorageManager.recordQuizResult(isCorrect, word.id);
    this.updateStatsDisplay();

    const fb = document.getElementById("polarity-feedback");
    fb.className = `feedback-box ${isCorrect ? "feedback-success" : "feedback-danger"}`;
    fb.innerHTML = `
      <div class="feedback-title">${isCorrect ? "✓ Spot On!" : "✗ Tone Misidentified"}</div>
      <div class="feedback-desc">
        <strong>${word.word}</strong> carries a <strong>${word.tone.toUpperCase()}</strong> tone in banking editorials.
        <br>${word.toneReason}
      </div>
      <div class="syn-ant-comparison">
        <div><strong>Synonyms:</strong> ${word.synonyms.join(", ")}</div>
        <div><strong>Antonyms:</strong> ${word.antonyms.join(", ")}</div>
      </div>
    `;
    fb.classList.remove("hidden");

    const nextBtn = document.getElementById("polarity-next-btn");
    nextBtn.classList.remove("hidden");
    nextBtn.onclick = () => {
      this.polarityIndex++;
      this.renderPolarityQuestion();
    };
  },

  showPolaritySummary: function() {
    const view = document.getElementById("view-polarity");
    const total = this.polarityQuestions.length * 10;
    const pct = Math.round((this.polarityScore / total) * 100);

    if (pct >= 80) fireConfetti();

    view.innerHTML = `
      <div class="summary-card">
        <div class="summary-badge">🎭 Reading Comprehension Master</div>
        <h2>Tone Polarity Drill Complete!</h2>
        <div class="summary-stats-grid">
          <div class="summary-stat-box">
            <span class="stat-big">${this.polarityScore} / ${total}</span>
            <span class="stat-lbl">Points</span>
          </div>
          <div class="summary-stat-box">
            <span class="stat-big">${pct}%</span>
            <span class="stat-lbl">Tone Accuracy</span>
          </div>
        </div>
        <p class="summary-hint">Recognizing positive vs negative word polarity gives you an edge in SBI PO author's tone and inference questions.</p>
        <div class="summary-actions">
          <button class="btn btn-primary" onclick="App.startPolarityQuiz()">🔄 Play Again</button>
          <button class="btn btn-secondary" onclick="App.switchTab('quiz')">📝 Test Exam MCQs</button>
        </div>
      </div>
    `;
  },

  // ==========================================
  // CONTEXTUAL CLOZE / EDITORIAL FILLERS
  // ==========================================
  startClozeQuiz: function() {
    this.clozeIndex = 0;
    this.clozeScore = 0;
    this.clozeAnswered = false;
    this.clozeQuestions = [...VOCAB_DATA].sort(() => 0.5 - Math.random()).slice(0, 10);
    this.renderClozeQuestion();
  },

  renderClozeQuestion: function() {
    const word = this.clozeQuestions[this.clozeIndex];
    if (!word) {
      this.showClozeSummary();
      return;
    }

    this.clozeAnswered = false;
    document.getElementById("cloze-feedback").classList.add("hidden");
    document.getElementById("cloze-next-btn").classList.add("hidden");

    document.getElementById("cloze-progress").textContent = `Editorial Passage ${this.clozeIndex + 1} of ${this.clozeQuestions.length}`;
    document.getElementById("cloze-score").textContent = `Score: ${this.clozeScore}`;

    // Sentence with placeholder
    document.getElementById("cloze-sentence").innerHTML = word.clozeSentence.replace(
      "________",
      `<span class="blank-slot" id="active-blank">[ ? ]</span>`
    );

    const container = document.getElementById("cloze-options");
    container.innerHTML = "";

    word.clozeOptions.forEach((opt, idx) => {
      const btn = document.createElement("button");
      btn.className = "quiz-option-btn";
      btn.innerHTML = `<span class="opt-letter">${String.fromCharCode(65 + idx)}</span> <span class="opt-text">${opt}</span>`;
      btn.onclick = () => this.handleClozeAnswer(opt, idx, btn, word);
      container.appendChild(btn);
    });
  },

  handleClozeAnswer: function(selectedOpt, optIdx, btn, word) {
    if (this.clozeAnswered) return;
    this.clozeAnswered = true;

    const correctOpt = word.clozeOptions[word.correctClozeIndex];
    const isCorrect = optIdx === word.correctClozeIndex;

    // Fill in blank slot
    const slot = document.getElementById("active-blank");
    if (slot) {
      slot.textContent = selectedOpt;
      slot.className = `blank-slot ${isCorrect ? "blank-correct" : "blank-wrong"}`;
    }

    document.querySelectorAll("#cloze-options .quiz-option-btn").forEach((b, i) => {
      b.disabled = true;
      if (i === word.correctClozeIndex) {
        b.classList.add("correct-option");
      } else if (b === btn && !isCorrect) {
        b.classList.add("wrong-option");
      }
    });

    if (isCorrect) {
      this.clozeScore += 10;
      SoundFX.playCorrect();
    } else {
      SoundFX.playWrong();
      StorageManager.recordMistake(word.id, "Editorial Cloze", selectedOpt, correctOpt);
    }

    StorageManager.recordQuizResult(isCorrect, word.id);
    this.updateStatsDisplay();

    const fb = document.getElementById("cloze-feedback");
    fb.className = `feedback-box ${isCorrect ? "feedback-success" : "feedback-danger"}`;
    fb.innerHTML = `
      <div class="feedback-title">${isCorrect ? "✓ Contextually Accurate!" : "✗ Contextual Mismatch"}</div>
      <div class="feedback-desc">
        Correct word: <strong>${correctOpt}</strong> (${word.pos}) - ${word.definition}
        <br><strong>Tone:</strong> ${word.tone.toUpperCase()} (${word.toneReason})
      </div>
    `;
    fb.classList.remove("hidden");

    const nextBtn = document.getElementById("cloze-next-btn");
    nextBtn.classList.remove("hidden");
    nextBtn.onclick = () => {
      this.clozeIndex++;
      this.renderClozeQuestion();
    };
  },

  showClozeSummary: function() {
    const view = document.getElementById("view-cloze");
    const total = this.clozeQuestions.length * 10;
    const pct = Math.round((this.clozeScore / total) * 100);

    if (pct >= 80) fireConfetti();

    view.innerHTML = `
      <div class="summary-card">
        <div class="summary-badge">📰 Editorial Mastery</div>
        <h2>Cloze Test Completed!</h2>
        <div class="summary-stats-grid">
          <div class="summary-stat-box">
            <span class="stat-big">${this.clozeScore} / ${total}</span>
            <span class="stat-lbl">Points</span>
          </div>
          <div class="summary-stat-box">
            <span class="stat-big">${pct}%</span>
            <span class="stat-lbl">Accuracy</span>
          </div>
        </div>
        <p class="summary-hint">Contextual cloze tests are among the highest-scoring sections in SBI PO Mains.</p>
        <div class="summary-actions">
          <button class="btn btn-primary" onclick="App.startClozeQuiz()">🔄 New Cloze Set</button>
          <button class="btn btn-secondary" onclick="App.switchTab('polarity')">🎭 Tone Challenge</button>
        </div>
      </div>
    `;
  },

  // ==========================================
  // REVIEW VAULT / MISTAKES
  // ==========================================
  renderMistakesView: function() {
    const container = document.getElementById("mistakes-list");
    const mistakes = StorageManager.getMistakes();

    if (mistakes.length === 0) {
      container.innerHTML = `
        <div class="empty-state">
          <div class="empty-icon">🛡️</div>
          <h3>Vault is Clean!</h3>
          <p>You have zero unmastered mistakes. Every word you attempted has been answered correctly.</p>
          <button class="btn btn-primary" onclick="App.switchTab('quiz')">Take a Quiz Now</button>
        </div>
      `;
      return;
    }

    container.innerHTML = `
      <div class="vault-header">
        <p>Found <strong>${mistakes.length}</strong> words needing revision. Answering them correctly in quizzes clears them from this vault.</p>
        <button class="btn btn-danger-outline" onclick="StorageManager.resetAllStats(); App.renderMistakesView();">Clear Vault</button>
      </div>
      <div class="mistakes-grid">
        ${mistakes.map(m => {
          const word = VocabBank.getById(m.wordId);
          if (!word) return "";
          return `
            <div class="mistake-card">
              <div class="mistake-top">
                <span class="mistake-word">${word.word}</span>
                <span class="tone-badge tone-${word.tone}">${word.tone.toUpperCase()}</span>
              </div>
              <div class="mistake-mode">Failed in: ${m.mode}</div>
              <div class="mistake-compare">
                <div class="txt-red">Your answer: <s>${m.userAns}</s></div>
                <div class="txt-green">Correct: <strong>${m.correctAns}</strong></div>
              </div>
              <div class="mistake-meaning"><strong>Definition:</strong> ${word.definition}</div>
              <div class="mistake-mnemonic">💡 <strong>Mnemonic:</strong> ${word.mnemonic}</div>
              <div class="mistake-actions">
                <button class="btn btn-sm btn-outline" onclick="App.openWordModal(${word.id})">🔍 Deep Dive</button>
                <button class="btn btn-sm btn-success-outline" onclick="StorageManager.removeMistake(${word.id}); App.renderMistakesView();">✓ Mark Mastered</button>
              </div>
            </div>
          `;
        }).join("")}
      </div>
    `;
  },

  // ==========================================
  // WORD DICTIONARY & SEARCH
  // ==========================================
  renderWordList: function(words = VOCAB_DATA) {
    const container = document.getElementById("dict-table-body");
    if (!container) return;

    if (words.length === 0) {
      container.innerHTML = `<tr><td colspan="6" class="text-center py-4">No matching words found.</td></tr>`;
      return;
    }

    container.innerHTML = words.map(w => {
      const isBookmarked = StorageManager.isBookmarked(w.id);
      return `
        <tr>
          <td>
            <button class="star-btn ${isBookmarked ? "bookmarked" : ""}" onclick="App.toggleWordBookmark(${w.id}, this)">
              ${isBookmarked ? "★" : "☆"}
            </button>
          </td>
          <td>
            <div class="dict-word-title" onclick="App.openWordModal(${w.id})">
              <strong>${w.word}</strong>
              <span class="pos-badge">${w.pos}</span>
            </div>
            <div class="dict-phonetic">${w.phonetic}</div>
          </td>
          <td>
            <span class="tone-badge tone-${w.tone}">${w.tone.toUpperCase()}</span>
          </td>
          <td>
            <div class="dict-syns">${w.synonyms.slice(0, 3).join(", ")}</div>
          </td>
          <td>
            <div class="dict-ants">${w.antonyms.slice(0, 3).join(", ")}</div>
          </td>
          <td>
            <button class="btn btn-sm btn-outline" onclick="App.jumpToCard(${w.id})">View Card</button>
          </td>
        </tr>
      `;
    }).join("");
  },

  filterDictionary: function() {
    const search = document.getElementById("dict-search").value.toLowerCase().trim();
    const toneFilter = document.getElementById("dict-tone-filter").value;
    const tierFilter = document.getElementById("dict-tier-filter").value;

    const filtered = VOCAB_DATA.filter(w => {
      const matchSearch = w.word.toLowerCase().includes(search) ||
        w.definition.toLowerCase().includes(search) ||
        w.synonyms.some(s => s.toLowerCase().includes(search));
      const matchTone = toneFilter === "all" || w.tone === toneFilter;
      const matchTier = tierFilter === "all" || w.tier.includes(tierFilter);
      return matchSearch && matchTone && matchTier;
    });

    this.renderWordList(filtered);
  },

  toggleWordBookmark: function(id, btn) {
    const active = StorageManager.toggleBookmark(id);
    btn.classList.toggle("bookmarked", active);
    btn.textContent = active ? "★" : "☆";
  },

  jumpToCard: function(id) {
    this.switchTab("flashcards");
    const idx = this.flashcardDeck.findIndex(w => w.id === id);
    if (idx !== -1) {
      this.flashcardIndex = idx;
    } else {
      this.flashcardDeck = [...VOCAB_DATA];
      this.flashcardIndex = this.flashcardDeck.findIndex(w => w.id === id);
    }
    this.isCardFlipped = false;
    this.renderCurrentCard();
  },

  openWordModal: function(id) {
    const word = VocabBank.getById(id);
    if (!word) return;

    let modal = document.getElementById("word-modal");
    if (!modal) {
      modal = document.createElement("div");
      modal.id = "word-modal";
      modal.className = "modal-overlay";
      document.body.appendChild(modal);
    }

    modal.innerHTML = `
      <div class="modal-box">
        <button class="modal-close-btn" onclick="document.getElementById('word-modal').remove()">✕</button>
        <div class="modal-header">
          <div>
            <h2>${word.word} <button class="audio-btn" onclick="speakWord('${word.word}')">🔊</button></h2>
            <div class="modal-sub">${word.phonetic} • <span class="pos-badge">${word.pos}</span> • ${word.tier}</div>
          </div>
          <span class="tone-badge tone-${word.tone}">${word.tone.toUpperCase()} TONE</span>
        </div>
        <div class="modal-body">
          <div class="modal-section">
            <h4>Definition</h4>
            <p>${word.definition}</p>
          </div>
          <div class="modal-section">
            <h4>Tone Analysis & Editorial Connotation</h4>
            <p>${word.toneReason}</p>
          </div>
          <div class="modal-grid">
            <div class="modal-col">
              <h4>Synonyms</h4>
              <div class="word-tag-container">${word.synonyms.map(s => `<span class="word-tag syn-tag">${s}</span>`).join("")}</div>
            </div>
            <div class="modal-col">
              <h4>Antonyms</h4>
              <div class="word-tag-container">${word.antonyms.map(a => `<span class="word-tag ant-tag">${a}</span>`).join("")}</div>
            </div>
          </div>
          <div class="modal-section">
            <h4>💡 Memory Hook (Mnemonic)</h4>
            <div class="modal-callout">${word.mnemonic}</div>
          </div>
          <div class="modal-section">
            <h4>📰 Bank PO Editorial Context</h4>
            <div class="editorial-quote">"${word.bankingContext}"</div>
          </div>
        </div>
      </div>
    `;
    modal.onclick = (e) => {
      if (e.target === modal) modal.remove();
    };
  },

  // ==========================================
  // STATS & THEME HELPERS
  // ==========================================
  updateStatsDisplay: function() {
    const stats = StorageManager.getStats();
    const streakEl = document.getElementById("stat-streak");
    if (streakEl) streakEl.textContent = stats.currentStreak;

    const accuracy = stats.totalQuestions > 0
      ? Math.round((stats.correctAnswers / stats.totalQuestions) * 100)
      : 0;

    const accEl = document.getElementById("stat-accuracy");
    if (accEl) accEl.textContent = `${accuracy}%`;

    const exploredEl = document.getElementById("stat-words-count");
    if (exploredEl) exploredEl.textContent = `${stats.wordsExplored.length} / ${VOCAB_DATA.length}`;

    const mistakes = StorageManager.getMistakes();
    const mistakeBadge = document.getElementById("vault-badge-count");
    if (mistakeBadge) {
      mistakeBadge.textContent = mistakes.length;
      mistakeBadge.style.display = mistakes.length > 0 ? "inline-block" : "none";
    }
  },

  toggleTheme: function() {
    const currentTheme = document.documentElement.getAttribute("data-theme") || "light";
    const newTheme = currentTheme === "light" ? "dark" : "light";
    document.documentElement.setAttribute("data-theme", newTheme);
    localStorage.setItem(StorageManager.STORAGE_KEYS.THEME, newTheme);
    const btn = document.getElementById("btn-toggle-theme");
    if (btn) btn.textContent = newTheme === "dark" ? "☀️ Light Mode" : "🌙 Dark Mode";
  }
};

// Initialize app when DOM is loaded
document.addEventListener("DOMContentLoaded", () => {
  // Restore theme
  const savedTheme = localStorage.getItem("bankpo_vocab_theme") || "light";
  document.documentElement.setAttribute("data-theme", savedTheme);
  const themeBtn = document.getElementById("btn-toggle-theme");
  if (themeBtn) themeBtn.textContent = savedTheme === "dark" ? "☀️ Light Mode" : "🌙 Dark Mode";

  App.init();
});
