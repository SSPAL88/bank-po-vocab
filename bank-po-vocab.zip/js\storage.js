// Storage & State Manager for BankPO VocabMaster
const StorageManager = {
  STORAGE_KEYS: {
    BOOKMARKS: "bankpo_vocab_bookmarks",
    MISTAKES: "bankpo_vocab_mistakes",
    STATS: "bankpo_vocab_stats",
    THEME: "bankpo_vocab_theme"
  },

  // Get Bookmarked Word IDs
  getBookmarks: function() {
    try {
      const data = localStorage.getItem(this.STORAGE_KEYS.BOOKMARKS);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      console.error("Storage error:", e);
      return [];
    }
  },

  // Toggle Bookmark for Word ID
  toggleBookmark: function(wordId) {
    let bookmarks = this.getBookmarks();
    if (bookmarks.includes(wordId)) {
      bookmarks = bookmarks.filter(id => id !== wordId);
    } else {
      bookmarks.push(wordId);
    }
    localStorage.setItem(this.STORAGE_KEYS.BOOKMARKS, JSON.stringify(bookmarks));
    return bookmarks.includes(wordId);
  },

  isBookmarked: function(wordId) {
    return this.getBookmarks().includes(wordId);
  },

  // Mistakes / Review Vault (stores wrong question attempts)
  getMistakes: function() {
    try {
      const data = localStorage.getItem(this.STORAGE_KEYS.MISTAKES);
      return data ? JSON.parse(data) : [];
    } catch (e) {
      return [];
    }
  },

  recordMistake: function(wordId, mode, userAns, correctAns) {
    let mistakes = this.getMistakes();
    // avoid duplicate word entries, update with latest
    mistakes = mistakes.filter(m => m.wordId !== wordId);
    mistakes.unshift({
      wordId: wordId,
      mode: mode,
      userAns: userAns,
      correctAns: correctAns,
      timestamp: new Date().toISOString()
    });
    // keep max 50 recent mistakes
    if (mistakes.length > 50) mistakes = mistakes.slice(0, 50);
    localStorage.setItem(this.STORAGE_KEYS.MISTAKES, JSON.stringify(mistakes));
  },

  removeMistake: function(wordId) {
    let mistakes = this.getMistakes().filter(m => m.wordId !== wordId);
    localStorage.setItem(this.STORAGE_KEYS.MISTAKES, JSON.stringify(mistakes));
  },

  // Stats (Attempts, Correct, Streak, High Streak)
  getStats: function() {
    try {
      const data = localStorage.getItem(this.STORAGE_KEYS.STATS);
      return data ? JSON.parse(data) : {
        totalQuestions: 0,
        correctAnswers: 0,
        currentStreak: 0,
        bestStreak: 0,
        wordsExplored: []
      };
    } catch (e) {
      return { totalQuestions: 0, correctAnswers: 0, currentStreak: 0, bestStreak: 0, wordsExplored: [] };
    }
  },

  recordQuizResult: function(isCorrect, wordId) {
    const stats = this.getStats();
    stats.totalQuestions += 1;
    if (isCorrect) {
      stats.correctAnswers += 1;
      stats.currentStreak += 1;
      if (stats.currentStreak > stats.bestStreak) {
        stats.bestStreak = stats.currentStreak;
      }
      // If answered correctly, remove from review vault if present
      if (wordId) this.removeMistake(wordId);
    } else {
      stats.currentStreak = 0;
    }

    if (wordId && !stats.wordsExplored.includes(wordId)) {
      stats.wordsExplored.push(wordId);
    }

    localStorage.setItem(this.STORAGE_KEYS.STATS, JSON.stringify(stats));
    return stats;
  },

  recordWordExplored: function(wordId) {
    const stats = this.getStats();
    if (!stats.wordsExplored.includes(wordId)) {
      stats.wordsExplored.push(wordId);
      localStorage.setItem(this.STORAGE_KEYS.STATS, JSON.stringify(stats));
    }
  },

  resetAllStats: function() {
    localStorage.removeItem(this.STORAGE_KEYS.STATS);
    localStorage.removeItem(this.STORAGE_KEYS.MISTAKES);
  }
};
